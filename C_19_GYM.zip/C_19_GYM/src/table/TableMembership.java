package table;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.*;

public class TableMembership extends AbstractTableModel{
    
    private List<Membership> list;
    
    public TableMembership(List<Membership> list){
        this.list = list;
    }
    
    public int getRowCount(){
        return list.size();
    }
    
    public int getColumnCount(){
        return 7;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex){
        switch (columnIndex){
            case 0:
                return list.get(rowIndex).getCustomer().getNama();
            case 1:
                return list.get(rowIndex).getPaketMembership();
            case 2:
                return list.get(rowIndex).getTanggalDaftar();
            case 3:
                return list.get(rowIndex).getTanggalAkhir();
            case 4:
                return list.get(rowIndex).getKontrak();
            case 5:
                return list.get(rowIndex).getNomorKartu();
            case 6:
                return list.get(rowIndex).getHargaMembership();
            case 7:
                return list.get(rowIndex).getId_membership();
            case 8:
                return list.get(rowIndex).getCustomer().getId_customer();
            default:
                return null;
        }
    }
    
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "Nama Customer";
            case 1:
                return "Paket Membership";
            case 2:
                return "Tanggal Daftar";
            case 3:
                return "Tanggal Berakhir";
            case 4:
                return "Kontrak";
            case 5:
                return "Nomor Kartu";
            case 6:
                return "Harga Membership";
            default:
                return null;
        }
    }
}
