
package table;


import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.*;

public class TablePayments extends AbstractTableModel{
    private List<Payments> list;
    
    public TablePayments(List<Payments> list){
        this.list = list;
    }
    
    public int getRowCount(){
        return list.size();
    }
    
    public int getColumnCount(){
        return 10;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex){
        switch (columnIndex){
            case 0:
                return list.get(rowIndex).getEmployee().getNama();
            case 1:
                return list.get(rowIndex).getCustomer().getNama();
            case 2:
                return list.get(rowIndex).getMembership().getPaketMembership();
            case 3:
                return list.get(rowIndex).getMembership().getTanggalDaftar();
            case 4:
                return list.get(rowIndex).getMembership().getTanggalAkhir();
            case 5:
                return list.get(rowIndex).getMembership().getNomorKartu();
            case 6:
                return list.get(rowIndex).getStatusPembayaran();
            case 7:
                return list.get(rowIndex).getTanggalPembayaran();
            case 8:
                return list.get(rowIndex).getTotalHarga();
            case 9:
                return list.get(rowIndex).getMetodePembayaran();
            case 10:
                return list.get(rowIndex).getMembership().getId_membership();
            case 11:
                return list.get(rowIndex).getEmployee().getId_employee();
            case 12:
                return list.get(rowIndex).getId_payments();
            case 13:
                return list.get(rowIndex).getCustomer().getId_customer();               
            default:
                return null;
        }
    }
    
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "Employee name";
            case 1:
                return "Customer name";
            case 2:
                return "Membership packet";
            case 3:
                return "Registration Date";
            case 4:
                return "End Date";
            case 5:
                return "Card Number";
            case 6:
                return "Payment Status";
            case 7:
                return "Payment Date";
            case 8:
                return "Total Payment";
            case 9:
                return "Payments Method";
            default:
                return null;
        }
    }
    
    
}
