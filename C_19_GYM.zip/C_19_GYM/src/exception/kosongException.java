/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exception;

import java.lang.Exception;

public class kosongException extends Exception{
    public kosongException(String message){
        super(message);
    }
}
