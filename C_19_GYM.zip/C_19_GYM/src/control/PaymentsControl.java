/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import dao.*;
import java.util.List;
import model.*;
import table.*;

public class PaymentsControl {
    private PaymentsDAO pDao = new PaymentsDAO();
    
    public void insertDataPayments(Payments p){
        pDao.insertPayments(p);
    }
    
    public TablePayments showPayments(String query){
        List <Payments> dataPayments = pDao.showPayments(query);
        TablePayments tablePayments = new TablePayments(dataPayments);
        
        return tablePayments;
    }
    
    public void updateDataPayments(Payments p){
        pDao.updatePayments(p);
    }
    
    public void deleteDataPayments(int id){
        pDao.deletePayments(id);
    }   
    public List<Payments> showListPayments(){
       List<Payments> dataPayments = pDao.showPayments();
       return dataPayments;
   }
}
