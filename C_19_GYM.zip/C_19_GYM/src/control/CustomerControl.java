/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import dao.CustomerDAO;
import java.util.List;
import model.Customer;
import table.TableCustomer;


public class CustomerControl {
    private CustomerDAO cDao = new CustomerDAO();
    
    public void insertDataCustomer(Customer c){
        cDao.insertCustomer(c);
    }
    
    public TableCustomer showCustomer(String query){
        List<Customer> dataCustomer = cDao.showCustomer(query);
        TableCustomer tableCustomer = new TableCustomer(dataCustomer);
        
        return tableCustomer;
    }
    
   public void updateDataCustomer(Customer c){
       cDao.updateCustomer(c);
   }
   
   public void deleteDataCustomer (int id){
       cDao.deleteCustomer(id);
   }
   
   public List<Customer> showListCustomer(){
       List<Customer> dataCustomer = cDao.showCustomer();
       return dataCustomer;
   }
   
   public Customer searchCustomer(String id){
        Customer c = null;
        c = cDao.searchCustomer(id);
        return c;
    }
   
//    public List<Dosen> showListDosen(){
//        List<Dosen> dataDosen = dDao.showDosen();
//        return dataDosen;
//    }
   
}