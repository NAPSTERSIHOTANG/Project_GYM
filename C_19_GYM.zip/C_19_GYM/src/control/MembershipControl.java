package control;

import dao.*;
import java.util.List;
import model.*;
import table.*;

public class MembershipControl {
    private MembershipDAO mDao = new MembershipDAO();
    
    public void insertDataMembership(Membership m){
        mDao.insertMembership(m);
    }
    
    public TableMembership showMembership(String query){
        
        List <Membership> dataMembership = mDao.showMembership(query);
        TableMembership tableMembership = new TableMembership(dataMembership);
        
        return tableMembership;
    }
    
//     public TableMataKuliah showMataKuliah(String query){
//        List<MataKuliah> dataMataKuliah = mkDao.showMataKuliah(query);
//        TableMataKuliah tableMataKuliah = new TableMataKuliah(dataMataKuliah);
//        
//        return tableMataKuliah;
//    
     public void updateDataMembership(Membership m){
       mDao.updateMembership(m);
    }
    
    public void deleteDataMembership(int id){
        mDao.deleteMembership(id);
    } 
   
   public List<Membership> showListMembership(){
       List<Membership> dataMembership = mDao.showMembership();
       return dataMembership;
   }
}
