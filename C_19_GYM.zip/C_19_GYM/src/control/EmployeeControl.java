package control;

import dao.*;
import java.util.List;
import model.*;
import table.*;

public class EmployeeControl {
    private EmployeeDAO eDao = new EmployeeDAO();
    
    public void insertDataEmployee(Employee e){
        eDao.insertEmployee(e);
    }
    
    public TableEmployee showEmployee(String query){
        List<Employee> dataEmployee = eDao.showEmployee(query);
        TableEmployee tableEmployee = new TableEmployee(dataEmployee);
        
        return tableEmployee;
    }
    
    public void updateDataEmployee(Employee e){
       eDao.updateEmployee(e);
    }
   
   public void deleteDataEmployee (int id){
       eDao.deleteEmployee(id);
   }
   
   public List<Employee> showListEmployee(){
       List<Employee> dataEmployee = eDao.showEmployee();
       return dataEmployee;
   }
}