/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import connection.DbConnection;
import java.sql.Connection; 
import java.sql.ResultSet; 
import java.sql.Statement; 
import java.util.ArrayList; 
import java.util.List;
import model.*;
public class EmployeeDAO {
    private DbConnection dbCon = new DbConnection();
    private Connection con;
    
    public void insertEmployee(Employee e){
         con = dbCon.makeConnection();       
         String sql;
     
//            sql = "INSERT INTO customer(id, nama, ktp, no_telepon)" + 
//                        "VALUES ('"+ c.getId() +"', '"+ c.getNama() +"', '"+ c.getKtp() +"','"+ c.getNo_telpon() +"')";
            sql = "INSERT INTO employee(id_employee, nama, umur, jabatan, noTelepon)" + 
                        "VALUES ('"+ e.getId_employee() + "','" + e.getNama() + "','" + e.getUmur() + "','" + e.getJabatan() + "','" + e.getNoTelepon() + "')";
            
          System.out.println("Adding Employee ... ");
                    try{
                       Statement statement = con.createStatement(); 
                       int result = statement.executeUpdate(sql); //executeUpdate digunakna untuk insert,update,delete dengan mengembalikan tipe data yang berbeda
                       System.out.println("Added " + result + " Employee"); 
                       statement.close(); 
                  }catch(Exception ee){
                          System.out.println("Error adding Employee...");
                          System.out.println(ee);
                  }
                     //dalam tanda kurung tersebut menggunakan ' karena merupakan bagian dari string, jika value seperti tidak perlu membungkusnya dengan '
        
       
        
        dbCon.closeConnection();
    }
    
    public List<Employee> showEmployee(String query){
        con = dbCon.makeConnection();
        
        String sql = "SELECT * FROM employee WHERE "
                + "(id_employee LIKE "
                + "'%" +query +"%'"
                + "OR nama LIKE '%" +query +"%'"
                + "OR umur LIKE '%" +query +"%'"
                + "OR jabatan LIKE '%" +query +"%'"
                + "OR noTelepon LIKE '%" +query +"%')";
        
        System.out.println("Mengambil data employee.. ");
        
        List<Employee> list = new ArrayList<>();
        
        try{
            
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs != null){
                while(rs.next()){
                    Employee e = new Employee(Integer.parseInt(rs.getString("id_employee")), 
                            rs.getString("nama"),
                            Integer.parseInt(rs.getString("umur")),                            
                            rs.getString("jabatan"),
                            rs.getString("noTelepon"));
                    list.add(e);
                }
            }
            rs.close();
            statement.close();
        }catch(Exception e){
            System.out.println("Error adding customer.. ");
            System.out.println(e);
        }
        dbCon.closeConnection();
        return list;
    }
    
    public List<Employee> showEmployee(){
        con = dbCon.makeConnection();
        
        String sql = "SELECT * FROM employee";
        System.out.println("Mengambil data employee.. ");
        
        List<Employee> list = new ArrayList<>();
        
        try{
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs != null){
                while(rs.next()){
                    Employee e = new Employee(Integer.parseInt(rs.getString("id_employee")) , 
                            rs.getString("nama"),
                            Integer.parseInt(rs.getString("umur")),
                            rs.getString("jabatan"),
                            rs.getString("noTelepon"));
                    list.add(e);
                }
            }
            rs.close();
            statement.close();
        }catch(Exception e){
            System.out.println("Error adding Employee.. ");
            System.out.println(e);
        }
        
        return list;
    }
    
    public void updateEmployee(Employee e){
        con = dbCon.makeConnection();
        
        String sql = "UPDATE employee SET id_employee = '" +e.getId_employee()+"', "
                +"nama = '" +e.getNama()+ "', "
                +"umur = '" +e.getUmur() +"', "
                +"jabatan = '" +e.getJabatan() +"', "
                +"noTelepom = '" + e.getNoTelepon() +"' "
                +"WHERE id_employee = '" +e.getId_employee()+"'";
        
        System.out.println("Editing Employee.. ");
        
        try{
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            System.out.println("Edited " +result + " Employee " + e.getId_employee());
            statement.close();
        }catch(Exception ee){
            System.out.println("Error editing employee.. ");
            System.out.println(ee);
        }
        
        dbCon.closeConnection();
    }
    
    public void deleteEmployee(int id){
        con = dbCon.makeConnection();
        
        String sql = "DELETE FROM employee WHERE id_employee = '" + id +"'";
        System.out.println("Deleting Employee.. ");
        
        try{
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            System.out.println("Delete " +result + " Employee " +id);
            statement.close();
        }catch(Exception e){
            System.out.println("Error deleting Employee.. ");
            System.out.println(e);
        }
        dbCon.closeConnection();
    }
}
