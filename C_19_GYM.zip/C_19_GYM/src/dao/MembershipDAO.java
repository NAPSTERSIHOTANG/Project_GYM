package dao;


import connection.DbConnection;
import java.sql.Connection; 
import java.sql.ResultSet; 
import java.sql.Statement; 
import java.util.ArrayList; 
import java.util.List; 
import dao.*;
import model.*;


public class MembershipDAO {
    private DbConnection dbCon = new DbConnection();
    private Connection con;
    
    public void insertMembership(Membership m){
       con = dbCon.makeConnection();
        
        String sql = "INSERT INTO membership(id_customer, paketMembership, tanggalDaftar, tanggalAkhir, hargaMembership, kontrak, nomorKartu) VALUES ('"
                + m.getCustomer().getId_customer() + "','" + m.getPaketMembership() + "','" + m.getTanggalDaftar() + "','"
                + m.getTanggalAkhir() + "','"
                + m.getHargaMembership()+ "','"
                + m.getKontrak() + "','"
                + m.getNomorKartu() + "')";       
                                                                       
        System.out.println("Adding Membership");
        
        try{
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            System.out.println("Added " + result + " Membership");
            statement.close();
            
        }catch (Exception e){
            System.out.println("Error adding Membership");
            System.out.println(e);
            
        }
        
        dbCon.closeConnection();
    }
    
    public List<Membership> showMembership(String query){
        con = dbCon.makeConnection();                       
         
         String sql = "SELECT m.*, c.* FROM membership as m JOIN customer as c on c.id_customer = m.id_customer WHERE (m.paketMembership LIKE "
                + "'%" + query + "%'"
                + "OR m.tanggalDaftar LIKE '%" + query + "%'"
                + "OR m.tanggalAkhir LIKE '%" + query + "%'"
                + "OR m.hargaMembership LIKE '%" + query + "%'"
                + "OR m.kontrak LIKE '%" + query + "%'"
                + "OR m.nomorKartu LIKE '%" + query + "%'"
                + "OR c.nama LIKE '%" + query + "%')";
         
//         String sql = "SELECT mk.*, d.* FROM mata_kuliah as mk JOIN dosen as d on d.nomor_induk_dosen = mk.nomor_induk_dosen WHERE (mk.nama LIKE "
//                + "'%" + query + "%'"
//                + "OR mk.deskripsi LIKE '%" + query + "%'"
//                + "OR mk.metode_pembelajaran LIKE '%" + query + "%'"
//                + "OR mk.kelas LIKE '%" + query + "%'"
//                + "OR d.nama LIKE '%" + query + "%')";
        
        System.out.println("Mengambil data Membership...");
        
        List<Membership> list = new ArrayList();
         
        try{
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs!= null){
                while(rs.next()){
                    
                    Customer c = new Customer(Integer.parseInt(rs.getString("c.id_customer")),
                    rs.getString("c.nama"), Integer.parseInt(rs.getString("c.umur")),
               rs.getString("c.noTelepon"), rs.getString("c.jenisKelamin"));
                    
                    
                    Membership m = new Membership(Integer.parseInt(rs.getString("m.id_membership")),
                    rs.getString("m.paketMembership"), rs.getString("m.tanggalDaftar"), rs.getString("m.tanggalAkhir"), Double.parseDouble(rs.getString("m.hargaMembership")),
                    Integer.parseInt(rs.getString("m.kontrak")), rs.getString("m.nomorKartu"),
                    c);
                    
//                    Membership m = new Membership(Integer.parseInt(rs.getString("membership.id_membership")),
//                    rs.getString("membership.paketMembership"), rs.getString("membership.tanggalDaftar"), rs.getString("membership.tanggalAkhir"), Double.parseDouble(rs.getString("membership.hargaMembership")),
//                    Integer.parseInt(rs.getString("membership.kontrak")), rs.getString("membership.nomorKartu"),
//                    c);                  
                    list.add(m);
                } 
            }
            rs.close();  
            statement.close();
            
        }catch (Exception e){
            System.out.println("Error reading database");
            System.out.println(e);
        }
        
        dbCon.closeConnection();
        return list;
    }
    
    public List<Membership> showMembership(){
        con = dbCon.makeConnection();
        
        String sql = "SELECT m.*, c.* FROM membership as m JOIN customer as c on c.id_customer = m.id_customer";
        System.out.println("Mengambil data membership.. ");
        
        List<Membership> list = new ArrayList<>();
        
        try{
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs != null){
                while(rs.next()){
                    //mark salah
                    Customer c = new Customer(Integer.parseInt(rs.getString("c.id_customer")),
                    rs.getString("c.nama"), Integer.parseInt(rs.getString("c.umur")),
               rs.getString("c.noTelepon"), rs.getString("c.jenisKelamin"));
                    
                    
                    Membership m = new Membership(Integer.parseInt(rs.getString("m.id_membership")),
                    rs.getString("m.paketMembership"), rs.getString("m.tanggalDaftar"), rs.getString("m.tanggalAkhir"), Double.parseDouble(rs.getString("m.hargaMembership")),
                    Integer.parseInt(rs.getString("m.kontrak")), rs.getString("m.nomorKartu"),
                    c);
                    
                    list.add(m);
                }
            }
            rs.close();
            statement.close();
        }catch(Exception e){
            System.out.println("Error adding Membership.. ");
            System.out.println(e);
        }
        
        return list;
    }
    
    public void deleteMembership(int id){
        con = dbCon.makeConnection();
        
        String sql = "DELETE FROM membership WHERE id_membership = " + id + "";
        System.out.println("Deleting Membership");
        
        try{
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            System.out.println("Delete " + result + " Membership" + id);
            statement.close();
        }catch (Exception e){
            System.out.println("Error deleting membership");
            System.out.println(e);
        }
        dbCon.closeConnection();
    }
    
    public void updateMembership(Membership m){
        con = dbCon.makeConnection();
        
        String sql = "UPDATE membership SET id_customer = '" + m.getCustomer().getId_customer()
                + "', paketMembership = '" + m.getPaketMembership()
                + "', tanggalDaftar = '" + m.getTanggalDaftar()
                + "', tanggalAkhir = '" + m.getTanggalAkhir()
                + "', hargaMembership = '" + m.getHargaMembership()
                + "', kontrak = '" + m.getKontrak()
                + "', nomorKartu = '" + m.getNomorKartu()
                + "' WHERE id = '" + m.getId_membership() + "'";
        System.out.println("Editing Membership");
        
        try{
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            System.out.println("Edited " + result + " Membership " + m.getId_membership());
            statement.close();
        }catch (Exception e){
            System.out.println("Error editing membership");
            System.out.println(e);
        }
        
        dbCon.closeConnection();
    }
    
}
