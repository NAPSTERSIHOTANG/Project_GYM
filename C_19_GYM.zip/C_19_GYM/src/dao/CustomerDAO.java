/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import connection.DbConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Customer;

public class CustomerDAO {
    private DbConnection dbCon = new DbConnection();
    private Connection con;
    
    public void insertCustomer(Customer c){
        con = dbCon.makeConnection();
        
        String sql = "INSERT INTO customer(id_customer, nama, umur, noTelepon, jenisKelamin)"
                + "VALUES ('" +c.getId_customer() +"', '" +c.getNama() +"', '" +c.getUmur()
                +"', '" +c.getNoTelepon()+"', '" +c.getJenisKelamin() +"')";
        
        System.out.println("Adding Customer.. ");
        
        try {
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            System.out.println("Added " + result );
            statement.close();
        } catch (Exception e) {
            System.out.println("Error adding customer...");
            System.out.println(e);
        }
        dbCon.closeConnection();
    }
    
    public List<Customer> showCustomer(String query){
        con = dbCon.makeConnection();
        
//        String sql = "SELECT * FROM customer WHERE "
//                + "(nama LIKE '%" +query +"%'"
//                + "OR umur LIKE '%" +query +"%'"
//                + "OR noTelepon LIKE '%" +query +"%'"
//                + "OR jenisKelamin LIKE '%" +query +"%')";
//        
        String sql = "SELECT * FROM customer WHERE "
                + "(id_customer LIKE "
                + "'%" +query +"%'"
                + "OR nama LIKE '%" +query +"%'"
                + "OR umur LIKE '%" +query +"%'"
                + "OR noTelepon LIKE '%" +query +"%'"
                + "OR jenisKelamin LIKE '%" +query +"%')";
        System.out.println("Mengambil data customer.. ");
        
        List<Customer> list = new ArrayList<>();
        
        try{
            
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs != null){
                while(rs.next()){
                    Customer c = new Customer(Integer.parseInt(rs.getString("id_customer")), 
                            rs.getString("nama"),
                            Integer.parseInt(rs.getString("umur")),
                            rs.getString("noTelepon"),
                            rs.getString("jenisKelamin"));
                    list.add(c);
                }
            }
            rs.close();
            statement.close();
        }catch(Exception e){
            System.out.println("Error adding customer.. ");
            System.out.println(e);
        }
        dbCon.closeConnection();
        return list;
    }
    
    public List<Customer> showCustomer(){
        con = dbCon.makeConnection();
        
        String sql = "SELECT * FROM customer";
        System.out.println("Mengambil data customer.. ");
        
        List<Customer> list = new ArrayList<>();
        
        try{
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs != null){
                while(rs.next()){
                    Customer c = new Customer(Integer.parseInt(rs.getString("id_customer")), 
                            rs.getString("nama"),
                            Integer.parseInt(rs.getString("umur")),
                            rs.getString("noTelepon"),
                            rs.getString("jenisKelamin"));
                    list.add(c);
                }
            }
            rs.close();
            statement.close();
        }catch(Exception e){
                          System.out.println("Error adding Costumer...");
                          System.out.println(e);
         }
        dbCon.closeConnection();
        return list;
    }     
         
    public void updateCustomer(Customer c){
        con = dbCon.makeConnection();
        
        String sql = "UPDATE customer SET id_customer = '" +c.getId_customer()+"', "
                +"nama = '" +c.getNama()+ "', "
                +"umur = '" +c.getUmur() +"', "
                +"noTelepon = '" +c.getNoTelepon() +"', "
                +"jenisKelamin = '" +c.getJenisKelamin() +"' "
                +"WHERE id_customer = '" +c.getId_customer()+"'";
        
        System.out.println("Editing customer.. ");
        
        try{
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            System.out.println("Edited " +result + " Customer " +c.getId_customer());
            statement.close();
        }catch(Exception e){
            System.out.println("Error editing customer.. ");
            System.out.println(e);
        }
        dbCon.closeConnection();
    }
    
    public void deleteCustomer(int id){
        con = dbCon.makeConnection();   
        
        String sql = "DELETE FROM customer WHERE id_customer = " + id + "";
        System.out.println("Deleting customer.. ");
        
        try{
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            
            System.out.println("Delete " +result + " Customer " +id);
            statement.close();
        }catch(Exception e){
            System.out.println("Error deleting customer.. ");
            System.out.println(e);
        }
        dbCon.closeConnection();
    }
    
    public Customer searchCustomer(String id){
        con = dbCon.makeConnection();
        
        String sql = "SELECT * FROM customer WHERE id_customer = '" + id + "'";
        System.out.println("Searching Customer...");
        Customer c = null;
        
        try{
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs != null){
               while (rs.next()){
                   c = new Customer(
                           Integer.parseInt(rs.getString("id_customer")),
                            rs.getString("nama"),
                            Integer.parseInt(rs.getString("umur")),
                            rs.getString("noTelepon"),
                            rs.getString("jenisKelamin")
                   );
//                   int id_customer, String nama, int umur, String noTelepon, String jenisKelamin
//String nama, int umur, String noTelepon, String jenisKelamin
               }
            }
            rs.close();
            statement.close();
        }catch (Exception e){
            System.out.println("Error reading database...");
            System.out.println(e);
        }
        dbCon.closeConnection();
        
        return c;
    }
}
