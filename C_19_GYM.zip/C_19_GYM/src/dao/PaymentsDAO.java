/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import connection.DbConnection;
import java.sql.Connection; 
import java.sql.ResultSet; 
import java.sql.Statement; 
import java.util.ArrayList; 
import java.util.List; 
import dao.*;
import model.*;

public class PaymentsDAO {
    
    private DbConnection dbCon = new DbConnection();
    private Connection con;
    
    public void insertPayments(Payments p){
       con = dbCon.makeConnection();
        
       String sql = "INSERT INTO payments(id_customer, id_membership, id_employee, totalHarga, metodePembayaran, statusPembayaran, tanggalPembayaran) VALUES ('"
                + p.getCustomer().getId_customer() + "','" + p.getMembership().getId_membership() + "','" + p.getEmployee().getId_employee() + "','"
                + p.getTotalHarga() + "','"
                + p.getMetodePembayaran() + "','"
                + p.getStatusPembayaran() + "','"
                + p.getTanggalPembayaran() + "')";
                                                                
        System.out.println("Adding Payments");
        
        try{
            Statement statement = con.createStatement();
            int result = statement.executeUpdate(sql);
            System.out.println("Added " + result + " Payments");
            statement.close();
            
        }catch (Exception e){
            
            System.out.println("Error adding Payments");
            System.out.println(e);      
        }
        
        dbCon.closeConnection();
    }
    
    public List<Payments> showPayments(String query){
        con = dbCon.makeConnection();
//                  SELECT m.*, c.* FROM membership as m JOIN customer as c on c.id_customer = m.id_customer WHERE (m.paketMembership LIKE
         String sql = "SELECT p.*, m.*, c.*, e.* FROM payments as p JOIN membership as m ON p.id_membership = m.id_membership JOIN customer as c ON m.id_customer = c.id_customer JOIN employee as e ON p.id_employee = e.id_employee WHERE (e.nama LIKE "
                + "'%" + query + "%'"
                + "OR c.nama LIKE '%" + query + "%'"
                + "OR m.paketMembership LIKE '%" + query + "%'"
                + "OR m.tanggalDaftar LIKE '%" + query + "%'"
                + "OR m.tanggalAkhir LIKE '%" + query + "%'"
                + "OR m.nomorKartu LIKE '%" + query + "%'"
                + "OR p.statusPembayaran LIKE '%" + query + "%'"
                + "OR p.tanggalPembayaran LIKE '%" + query + "%'"
                + "OR p.metodePembayaran LIKE '%" + query + "%'"
                + "OR p.totalHarga LIKE '%" + query + "%')";
         
        
        System.out.println("Mengambil data Payments...");
        
        List<Payments> list = new ArrayList();
        
        try{
            
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs != null){
                while(rs.next()){
                    
                    Customer c = new Customer(Integer.parseInt(rs.getString("c.id_customer")),
                    rs.getString("c.nama"), Integer.parseInt(rs.getString("c.umur")),
                    rs.getString("c.noTelepon"), rs.getString("c.jenisKelamin"));
                                       
                    Membership m = new Membership(Integer.parseInt(rs.getString("m.id_membership")),
                    rs.getString("m.paketMembership"), rs.getString("m.tanggalDaftar"), rs.getString("m.tanggalAkhir"), Double.parseDouble(rs.getString("m.hargaMembership")),
                    Integer.parseInt(rs.getString("m.kontrak")), rs.getString("m.nomorKartu"),
                    c);
                    
                    Employee e = new Employee(Integer.parseInt(rs.getString("e.id_employee")) , 
                            rs.getString("e.nama"),
                            Integer.parseInt(rs.getString("e.umur")),
                            rs.getString("e.jabatan"),
                            rs.getString("e.noTelepon"));
                    
                    Payments p = new Payments(Integer.parseInt(rs.getString("p.id_payments")),
                    Double.parseDouble(rs.getString("p.totalHarga")), rs.getString("p.metodePembayaran"), rs.getString("p.statusPembayaran"), rs.getString("p.tanggalPembayaran"), c, m, e);
                   
                    list.add(p);                                                         
                }
            }
            
            rs.close();
            statement.close();
            
        }catch(Exception e){
            System.out.println("");
            System.out.println(e);
        }
        
        dbCon.closeConnection();
        return list;
    }
    
     public List<Payments> showPayments(){
        con = dbCon.makeConnection();
        
        String sql = "SELECT * FROM payments";
        System.out.println("Mengambil data payments.. ");
        
        List<Payments> list = new ArrayList<>();
        
        try{
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if(rs != null){
                while(rs.next()){
                    Customer c = new Customer(Integer.parseInt(rs.getString("c.id_customer")),
                    rs.getString("c.nama"), Integer.parseInt(rs.getString("c.umur")),
                    rs.getString("c.noTelepon"), rs.getString("c.jenisKelamin"));
                    
                    
                    Membership m = new Membership(Integer.parseInt(rs.getString("m.id_membership")),
                    rs.getString("m.paketMembership"), rs.getString("m.tanggalDaftar"), rs.getString("m.tanggalAkhir"), Double.parseDouble(rs.getString("m.hargaMembership")),
                    Integer.parseInt(rs.getString("m.kontrak")), rs.getString("m.nomorKartu"),
                    c);
                    
                    Employee e = new Employee(rs.getInt("id_employee"), 
                            rs.getString("nama"),
                            rs.getInt("umur"),
                            rs.getString("jabatan"),
                            rs.getString("noTelepon"));
                    
                    Payments p = new Payments(Integer.parseInt(rs.getString("p.id_payments")),
                    Double.parseDouble(rs.getString("p.totalHarga")), rs.getString("p.metodePembayaran"), rs.getString("p.statusPembayaran"), rs.getString("p.tanggalPembayaran"), c, m, e);
                   
                    list.add(p);
                }
            }
            rs.close();
            statement.close();
        }catch(Exception e){
            System.out.println("Error adding Payments.. ");
            System.out.println(e);
        }
        
        return list;
    }
    
     public void updatePayments(Payments p){
        
        con = dbCon.makeConnection();      
        
        String sql = "UPDATE payments SET id_customer = '" + p.getCustomer().getId_customer()
                + "', id_membership = '" + p.getMembership().getId_membership()
                + "', id_employee = '" + p.getEmployee().getId_employee()
                + "', totalHarga = '" + p.getTotalHarga()
                + "', metodePembayaran = '" + p.getMetodePembayaran()              
                + "', statusPembayaran = '" + p.getStatusPembayaran()
                + "', tanggalPembayaran = '" + p.getTanggalPembayaran()
                + "' WHERE id_payments = '" + p.getId_payments()+ "'";                       
        
        System.out.println("Editing payments..."); 
        
        try{
            Statement statement = con.createStatement(); 
             int result = statement.executeUpdate(sql); 
            
            System.out.println("Edited "+ result + " Payments " + p.getId_payments());
            statement.close();
            
        }catch(Exception e){
            System.out.println("Error Editing Penyewaan...");
        }
        
        dbCon.closeConnection();
    }
     
    public void deletePayments(int id){
        con = dbCon.makeConnection();
        
        String sql = "DELETE FROM payments WHERE id_payments = " + id + "";
        
        System.out.println("Deleting Payments...");
        
        try{
            Statement statement = con.createStatement(); 
            int result = statement.executeUpdate(sql); 
            System.out.println("Delete " + result + " Payments" + id);
            statement.close();
            
        }catch(Exception e){
            System.out.println("Error Deleting payments...");
            System.out.println(e);
        }
        
        dbCon.closeConnection();
    }
}
