package model;


public class Customer {
    private int id_customer;
    private String nama;
    private int umur;
    private String noTelepon;
    private String jenisKelamin;

 
    public Customer(int id_customer, String nama, int umur, String noTelepon, String jenisKelamin) {
        this.id_customer = id_customer;
        this.nama = nama;
        this.umur = umur;
        this.noTelepon = noTelepon;
        this.jenisKelamin = jenisKelamin;
    }

    
    public Customer(String nama, int umur, String noTelepon, String jenisKelamin) {
        this.nama = nama;
        this.umur = umur;
        this.noTelepon = noTelepon;
        this.jenisKelamin = jenisKelamin;
    }

    public int getId_customer() {
        return id_customer;
    }

    public String getNama() {
        return nama;
    }

    public int getUmur() {
        return umur;
    }

    public String getNoTelepon() {
        return noTelepon;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public void setId_customer(int id_customer) {
        this.id_customer = id_customer;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public void setNoTelepon(String noTelepon) {
        this.noTelepon = noTelepon;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

//     public String showDataCustomer(){
//        return this.id + "|" + this.nama +"|"+ this.ktp + "|" + this.no_telpon;
//    } 
    
    @Override
    public String toString(){
        return nama;
    }
    
}
