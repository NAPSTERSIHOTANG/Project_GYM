package model;


public class Membership {
    private int id_membership;
    private String paketMembership;
    private String tanggalDaftar;
    private String tanggalAkhir;
    private double hargaMembership;
    private int kontrak;
    private String nomorKartu;
    private Customer customer;

    public Membership(int id_membership, String paketMembership, String tanggalDaftar, String tanggalAkhir, double hargaMembership, int kontrak, String nomorKartu, Customer customer) {
        this.id_membership = id_membership;
        this.paketMembership = paketMembership;
        this.tanggalDaftar = tanggalDaftar;
        this.tanggalAkhir = tanggalAkhir;
        this.hargaMembership = hargaMembership;
        this.kontrak = kontrak;
        this.nomorKartu = nomorKartu;
        this.customer = customer;
    }

    public Membership(String paketMembership, String tanggalDaftar, String tanggalAkhir, double hargaMembership, int kontrak, String nomorKartu, Customer customer) {
        this.paketMembership = paketMembership;
        this.tanggalDaftar = tanggalDaftar;
        this.tanggalAkhir = tanggalAkhir;
        this.hargaMembership = hargaMembership;
        this.kontrak = kontrak;
        this.nomorKartu = nomorKartu;
        this.customer = customer;
    }

    public int getId_membership() {
        return id_membership;
    }

    public String getPaketMembership() {
        return paketMembership;
    }

    public String getTanggalDaftar() {
        return tanggalDaftar;
    }

    public String getTanggalAkhir() {
        return tanggalAkhir;
    }

    public double getHargaMembership() {
        return hargaMembership;
    }

    public int getKontrak() {
        return kontrak;
    }

    public String getNomorKartu() {
        return nomorKartu;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setId_membership(int id_membership) {
        this.id_membership = id_membership;
    }

    public void setPaketMembership(String paketMembership) {
        this.paketMembership = paketMembership;
    }

    public void setTanggalDaftar(String tanggalDaftar) {
        this.tanggalDaftar = tanggalDaftar;
    }

    public void setTanggalAkhir(String tanggalAkhir) {
        this.tanggalAkhir = tanggalAkhir;
    }

    public void setHargaMembership(double hargaMembership) {
        this.hargaMembership = hargaMembership;
    }

    public void setKontrak(int kontrak) {
        this.kontrak = kontrak;
    }

    public void setNomorKartu(String nomorKartu) {
        this.nomorKartu = nomorKartu;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    
     @Override
    public String toString(){
        return nomorKartu;
    }
    
//     public String showDataCustomer(){
//        return this.id + "|" + this.nama +"|"+ this.ktp + "|" + this.no_telpon;
//    } 
    
}
