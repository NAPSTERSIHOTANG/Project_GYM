package model;


public class Payments {
    private int id_payments;
    private double totalHarga;
    private String metodePembayaran;
    private String statusPembayaran;
    private String tanggalPembayaran;
    
    private Customer customer;
    private Membership membership;
    private Employee employee;

    public Payments(int id_payments, double totalHarga, String metodePembayaran, String statusPembayaran, String tanggalPembayaran, Customer customer, Membership membership, Employee employee) {
        this.id_payments = id_payments;
        this.totalHarga = totalHarga;
        this.metodePembayaran = metodePembayaran;
        this.statusPembayaran = statusPembayaran;
        this.tanggalPembayaran = tanggalPembayaran;
        this.customer = customer;
        this.membership = membership;
        this.employee = employee;
    }

    public Payments(double totalHarga, String metodePembayaran, String statusPembayaran, String tanggalPembayaran, Customer customer, Membership membership, Employee employee) {
        this.totalHarga = totalHarga;
        this.metodePembayaran = metodePembayaran;
        this.statusPembayaran = statusPembayaran;
        this.tanggalPembayaran = tanggalPembayaran;
        this.customer = customer;
        this.membership = membership;
        this.employee = employee;
    }

    public int getId_payments() {
        return id_payments;
    }

    public double getTotalHarga() {
        return totalHarga;
    }

    public String getMetodePembayaran() {
        return metodePembayaran;
    }

    public String getStatusPembayaran() {
        return statusPembayaran;
    }

    public String getTanggalPembayaran() {
        return tanggalPembayaran;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Membership getMembership() {
        return membership;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setId_payments(int id_payments) {
        this.id_payments = id_payments;
    }

    public void setTotalHarga(double totalHarga) {
        this.totalHarga = totalHarga;
    }

    public void setMetodePembayaran(String metodePembayaran) {
        this.metodePembayaran = metodePembayaran;
    }

    public void setStatusPembayaran(String statusPembayaran) {
        this.statusPembayaran = statusPembayaran;
    }

    public void setTanggalPembayaran(String tanggalPembayaran) {
        this.tanggalPembayaran = tanggalPembayaran;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setMembership(Membership membership) {
        this.membership = membership;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
    
//     public String showDataCustomer(){
//        return this.id + "|" + this.nama +"|"+ this.ktp + "|" + this.no_telpon;
//    } 
}
