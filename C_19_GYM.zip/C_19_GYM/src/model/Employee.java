
package model;

public class Employee {
    private int id_employee;
    private String nama;
    private int umur;
    private String jabatan;
    private String noTelepon;
    
    public Employee(int id_employee, String nama, int umur, String jabatan, String noTelepon) {
        this.id_employee = id_employee;
        this.nama = nama;
        this.umur = umur;
        this.jabatan = jabatan;
        this.noTelepon = noTelepon;
    }
    public Employee(String nama, int umur, String jabatan, String noTelepon) {
        this.nama = nama;
        this.umur = umur;
        this.jabatan = jabatan;
        this.noTelepon = noTelepon;
    }
    public int getId_employee() {
        return id_employee;
    }
    public String getNama() {
        return nama;
    }
    public int getUmur() {
        return umur;
    }
    public String getJabatan() {
        return jabatan;
    }
    public String getNoTelepon() {
        return noTelepon;
    }
    public void setId_employee(int id_employee) {
        this.id_employee = id_employee;
    }
    public void setNama(String nama) {
        this.nama = nama;
    }
    public void setUmur(int umur) {
        this.umur = umur;
    }
    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }
    public void setNoTelepon(String noTelepon) {
        this.noTelepon = noTelepon;
    }
    
    @Override
    public String toString(){
        return nama;
    }
    
//    public String showDataEmployee(){
//        return this.id_employee +" | " +this.nama + " | "
//                +this.umur + " | " +this.jabatan + " | " +this.noTelepon + " | ";
//    }
    
//    public String NoTelepon() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
    
}
